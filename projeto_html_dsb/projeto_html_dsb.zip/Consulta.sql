USE gibis;
CREATE  TABLE herois (
code_heroi INT PRIMARY KEY AUTO_INCREMENT,
cod_universo INT NOT NULL,
nome_heroi VARCHAR(30) NOT NULL,
qtd_poder INT,
fortuna DECIMAL(10,2),
codinome VARCHAR (30) NOT NULL,
FOREIGN KEY (cod_universo) REFERENCES universo (cod_universo)
);
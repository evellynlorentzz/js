/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Evellyn Lorentz
 */
public class veiculo {
    String marca;
    String modelo;
    int ano;

    public veiculo(String marca, String Modelo, int ano) {
        this.marca = marca;
        this.modelo = Modelo;
        this.ano = ano;
    }
    
    public void exibirInformacoes() {
        System.out.println("Marca: " + marca + ". Modelo: "+ modelo + ". Ano:"+ ano);
    }
}

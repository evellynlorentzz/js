/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Evellyn Lorentz
 */
public class Moto extends veiculo {
    int cilindradas;

    public Moto(String marca, String Modelo, int ano, int cilindradas) {
        super(marca, Modelo, ano);
        this.cilindradas = cilindradas;
    }

    @Override
    public void exibirInformacoes () {
        System.out.println("Cilindradas: " + cilindradas  );
    }
    
    
}

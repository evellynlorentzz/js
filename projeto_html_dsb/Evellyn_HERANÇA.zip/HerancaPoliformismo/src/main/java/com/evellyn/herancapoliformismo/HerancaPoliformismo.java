/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.evellyn.herancapoliformismo;

/**
 *
 * @author 24153578
 */
public class HerancaPoliformismo {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

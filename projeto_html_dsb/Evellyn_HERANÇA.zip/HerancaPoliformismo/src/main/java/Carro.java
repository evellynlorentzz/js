/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Evellyn Lorentz
 */
public class Carro extends veiculo {
    int quantidadeDePortas;

    public Carro(String marca, String Modelo, int quantidadeDePortas, int ano) {
        super(marca, Modelo, ano);
        this.quantidadeDePortas = quantidadeDePortas;
    }
    
    @Override
    public void exibirInformacoes () {
        System.out.println("Quantidade de Portas: " + quantidadeDePortas  );
    }
    
}

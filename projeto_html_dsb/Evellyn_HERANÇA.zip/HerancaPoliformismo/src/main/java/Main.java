/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 24153578
 */
public class Main {
    public static void main (String [] args) {
        Carro carro = new Carro ("Toyota", "Corolla", 2021, 4);
        System.out.println("Informações do Carro: ");
        carro.exibirInformacoes () ;
        System.out.println("|------------------------------------------------------------|");
        
        Moto moto = new Moto ("Honda", "CB-500", 2020, 500);
        System.out.println("Informações do Moto ");
        moto.exibirInformacoes();
        System.out.println("|-------------------------------------------------------------|");
        
        Caminhao caminhao = new Caminhao ("Volvo", "FH16",  2019, 30.0);
        System.out.println("Informações do Caminhão");
        caminhao.exibirInformacoes();   
        System.out.println("|---------------------------------------------------------------|");
                
    }
}

   

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Evellyn Lorentz
 */
public class Caminhao extends veiculo {
    double capacidadeDeCarga;
    private String volvo;

    public Caminhao(String marca, String Modelo, int ano, double capacidadeDeCarga) {
        super(marca, Modelo, ano);
        this.capacidadeDeCarga = capacidadeDeCarga;
    }

//    Caminhao (String Volvo, String fH16, int i) {
   //     throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    //    this.volvo = volvo;
   // }
    
    @Override
    public void exibirInformacoes () {
        System.out.println("Capacidade de Carga: " + capacidadeDeCarga + "t");
    }
}

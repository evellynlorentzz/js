
/**
 *
 * @author Evellyn Victoria Sousa Lorentz
 */
public class Main {
     public static void main(String[] args) {
        Cachorro cachorro = new Cachorro ("Snoop",5);
        System.out.println("Informaçoes do Cachorro: ");
        cachorro.exibirInformacoes();
        cachorro.fazersom();
        System.out.println("|--------------------------------|");
        
        Gato gato = new Gato("Garfild",3);
        System.out.println("Informaçoes da Gato: ");
        gato.exibirInformacoes();
        gato.fazersom();
        System.out.println("|------------------------|");
        
        Passaro passaro = new Passaro("Calopsita",1);
        System.out.println("Informaçoes do Passaro: ");
        passaro.exibirInformacoes();
        passaro.fazersom();
        System.out.println("|------------------------|");
    }
}

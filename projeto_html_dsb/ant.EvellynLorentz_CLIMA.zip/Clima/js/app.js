const apiKey = '21edcef46efb1946b5473bb1664fd822';
const city = 'Osasco'; // Altere para sua cidade desejada
const temperatureElement = document.getElementById('temperature');
const weatherImageElement = document.getElementById('weather-image');

// Função para buscar dados de clima
async function fetchWeatherData() {
    try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`);
        const data = await response.json();
        const temperature = data.main.temp;
        updateWeatherDisplay(temperature);
    } catch (error) {
        temperatureElement.textContent = "Erro ao obter dados do clima.";
    }
}
function updateWeatherDisplay(temperature){
    temperatureElement.textContent = `Temperatura: ${temperature}°C`;

    if(temperature > 30){
        weatherImageElement.innerHTML = `<img src="img/escaldante.jpg">`;
    }
    else if(temperature >= 19 && temperature <=29 ){
        weatherImageElement.innerHTML = `<img src="img/dia bonito ensolarado.avif">`;
    }
    else if(temperature >=9 && temperature >= 18){
        weatherImageElement.innerHTML = `<img src="img/dia nublado.jpg">`;
    }
    else if(temperature >=8 && temperature >= 1){
        weatherImageElement.innerHTML = `<img src="img/geada.jpg">`;
    }
    else{
        weatherImageElement.innerHTML = `<img src="img/neve frio.jpg">`;
    }
}
fetchWeatherData();
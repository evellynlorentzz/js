/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.evellyn.animal;

/**
 *
 * @author 24153578
 */
public class Animal  {
     
    public static void main(String[] args) {
        // TODO code application logic here
    Gato gatofofo = new Gato();
gatofofo.setCor("rosa");
        System.out.println("a cor do gato  eh" + gatofofo.getCor());
        
gatofofo.setNome("hellokitty");
        System.out.println("o nome do gato eh " + gatofofo.getNome());
Gato motor =new Gato ();
  motor.acenar();
    
        // TODO code application logic here
  cachorro cachorrofofo = new  cachorro();
cachorrofofo.setCor("roxa");
        System.out.println("a cor do cachorro  eh" + cachorrofofo.getCor());
        
cachorrofofo.setNome("heloisa");
        System.out.println("o nome do filhote eh " + cachorrofofo.getNome());
    }

}

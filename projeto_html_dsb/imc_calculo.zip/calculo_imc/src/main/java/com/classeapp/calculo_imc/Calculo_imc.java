package com.classeapp.calculo_imc;

public class Calculo_imc {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
